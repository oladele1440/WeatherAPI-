

```python
#Importing Dependencies
import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt 
from config import value_key
import seaborn as sns 
from citipy import citipy 
import requests as req
import time
import json
import random
%matplotlib inline

```


```python
#generating randomly a list of latitudes and longitudes 

latitude = []
longitude = []

for list_lat in np.random.randint(-90,90,800):
    latitude.append(list_lat)

for list_lon in np.random.randint(-180,180,900):
    longitude.append(list_lon)
```


```python
#Creating variable called latitude_and_Longitude and store all random latitudes and longitudes generated

latitude_and_Longitude = tuple(zip(latitude,longitude))
```


```python
#using citipy library to find the nearest city for all latitudes and longitudes

cities = []
country = []

for lat,lon in latitude_and_Longitude:
    city = citipy.nearest_city(lat,lon)
    
    cityName = city.city_name
    
    cities.append(cityName)
    
    country.append(city.country_code)
    
    
```


```python
#Printing out how many different cities were generated

print('The number of cities generated is {} using random cities and countries.'.format(len(set(cities))))
```

    The number of cities generated is 379 using random cities and countries.
    


```python
#creating a dataframe to store all the cities and countries generated with the citipy and 
#adding additional blank columns to store information from openweathermap api

df_countries = pd.DataFrame({'Cities': cities,
              'Country': country})

df_countries['Latitude'] = ""
df_countries['Longitude'] = ""
df_countries['Temperature (F)'] = ""
df_countries['Humidity (%)'] = ''
df_countries['Cloudiness (%)'] = ""
df_countries['Wind Speed (mph)'] = ""

df_countries.head(20)
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cities</th>
      <th>Country</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>Temperature (F)</th>
      <th>Humidity (%)</th>
      <th>Cloudiness (%)</th>
      <th>Wind Speed (mph)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>coatesville</td>
      <td>us</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>1</th>
      <td>ozernovskiy</td>
      <td>ru</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>2</th>
      <td>klaksvik</td>
      <td>fo</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>3</th>
      <td>troitskiy</td>
      <td>ru</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>4</th>
      <td>sao jose da coroa grande</td>
      <td>br</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>5</th>
      <td>mahebourg</td>
      <td>mu</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>6</th>
      <td>catalao</td>
      <td>br</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>7</th>
      <td>taolanaro</td>
      <td>mg</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>8</th>
      <td>ushuaia</td>
      <td>ar</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>9</th>
      <td>kapaa</td>
      <td>us</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>10</th>
      <td>jaruco</td>
      <td>cu</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>11</th>
      <td>puerto ayora</td>
      <td>ec</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>12</th>
      <td>rikitea</td>
      <td>pf</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>13</th>
      <td>quang ngai</td>
      <td>vn</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>14</th>
      <td>port elizabeth</td>
      <td>za</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>15</th>
      <td>ponta do sol</td>
      <td>cv</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>16</th>
      <td>lebu</td>
      <td>cl</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>17</th>
      <td>puerto ayora</td>
      <td>ec</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>18</th>
      <td>lavrentiya</td>
      <td>ru</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>19</th>
      <td>saskylakh</td>
      <td>ru</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>
</div>




```python
for index,row in df_countries.iterrows():
    city_name = row['Cities']
    Country_id = row['Country']
    
    
    #api call for all Cities 
    api_url = "http://api.openweathermap.org/data/2.5/forecast" \
    "?q={},{}&units=IMPERIAL&mode=json&APPID={}".format(city_name,Country_id,value_key)
    
    
    country_info = req.get(api_url).json()
    
    #print all api url's for each city
    print(api_url)
    
    
    try:
        df_countries.set_value(index,'Latitude',country_info['city']['coord']['lat'])
        df_countries.set_value(index,'Longitude',country_info['city']['coord']['lon'])
        df_countries.set_value(index,'Temperature (F)',country_info['list'][0]['main']['temp'])
        df_countries.set_value(index,'Humidity (%)',country_info['list'][0]['main']['humidity'])
        df_countries.set_value(index,'Cloudiness (%)',country_info['list'][0]['clouds']['all'])
        df_countries.set_value(index,'Wind Speed (mph)',country_info['list'][0]['wind']['speed'])
        
    except KeyError:
        df_countries.set_value(index,'Latitude',np.nan)
        df_countries.set_value(index,'Longitude',np.nan)
        df_countries.set_value(index,'Temperature (F)',np.nan)
        df_countries.set_value(index,'Humidity (%)',np.nan)
        df_countries.set_value(index,'Cloudiness (%)',np.nan)
        df_countries.set_value(index,'Wind Speed (mph)',np.nan)
        
        print('Missing weather information...skip')

```

    http://api.openweathermap.org/data/2.5/forecast?q=coatesville,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ozernovskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=klaksvik,fo&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=troitskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sao jose da coroa grande,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mahebourg,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=catalao,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jaruco,cu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=puerto ayora,ec&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=quang ngai,vn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port elizabeth,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ponta do sol,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lebu,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=puerto ayora,ec&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lavrentiya,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saskylakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=barrow,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ceres,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=makakilo city,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vaini,to&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tasiilaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mahebourg,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=da nang,vn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bethel,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=aksaray,tr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lebu,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=fortuna,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=chernyshevskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=zarubino,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=the valley,ai&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tessalit,ml&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=berlevag,no&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=leningradskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=illoqqortoormiut,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=madison,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bilibino,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kruisfontein,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sinnamary,gf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=katobu,id&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=qaanaaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=pozo colorado,py&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuatapere,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bathsheba,bb&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuatapere,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=flinders,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hilo,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=georgetown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bethel,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=faanui,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=alofi,nu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=avarua,ck&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=avarua,ck&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=denpasar,id&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=naftah,tn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=maine-soroa,ne&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=narsaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kabanjahe,id&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yirol,sd&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=georgetown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=belmonte,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saleaula,ws&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yellowknife,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=simao,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tabiauea,ki&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tiksi,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sentyabrskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=etchojoa,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=shihezi,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saurimo,ao&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nouadhibou,mr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yellowknife,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bandarbeyla,so&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=luena,ao&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saskylakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=paros,gr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kudahuvadhoo,mv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hilo,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=belushya guba,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port-cartier,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=new norfolk,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=geraldton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=innisfail,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lompoc,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=etla,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=karratha,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vaini,to&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tiksi,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mangai,cd&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saskylakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cabo san lucas,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=georgetown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=georgetown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=aksu,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=belushya guba,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=buraydah,sa&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mantua,cu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sept-iles,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=camargo,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=new norfolk,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=barrow,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=okhotsk,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mys shmidta,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=turukhansk,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=ahipara,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=chlorakas,cy&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=avarua,ck&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=illoqqortoormiut,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=port macquarie,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hasaki,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=los llanos de aridane,es&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ondorhaan,mn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=vaini,to&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hermanus,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=san rafael,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ilulissat,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=maykor,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=quelimane,mz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sarangani,ph&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=upernavik,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ilulissat,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tomatlan,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hearst,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=fevralsk,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=kununurra,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saskylakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kungurtug,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vilhena,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ahrarne,ua&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=thompson,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mahebourg,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kalengwa,zm&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=geraldton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sur,om&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=matelandia,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=te anau,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mys shmidta,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=vaini,to&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=malanje,ao&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=castro,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=eirunepe,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=barentsburg,sj&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=twin falls,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cedar city,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kautokeino,no&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=san quintin,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=attawapiskat,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=wrexham,gb&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=qaanaaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=umzimvubu,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=husavik,is&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=san pedro,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ribeira grande,pt&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=kaitangata,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=zaysan,kz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=attawapiskat,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=port said,eg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=torbay,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=faanui,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=georgetown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=carnarvon,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bereda,so&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lovozero,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=hasaki,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=puerto ayora,ec&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vaini,to&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lompoc,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=novosheshminsk,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sibu,my&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=syedove,ua&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=scottsbluff,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=sumbawa,id&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=sorvag,fo&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=zaysan,kz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=phan thiet,vn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=qaanaaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cherskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=grand river south east,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cherskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=belushya guba,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=rio gallegos,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=beloha,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rio gallegos,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=castro,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sovetskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hermanus,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=peleduy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=arraial do cabo,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hecelchakan,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nieuw nickerie,sr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=te anau,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=severo-kurilsk,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=hithadhoo,mv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=piacabucu,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=maniitsoq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tasiilaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ponta do sol,pt&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=butaritari,ki&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=aswan,eg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mumbwa,zm&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bambous virieux,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=avarua,ck&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yongan,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=puerto madryn,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=zavyalovo,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=amderma,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=leningradskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=katsuura,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=urumqi,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=coquimbo,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=fortuna,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=airai,pw&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=norman wells,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=grand-lahou,ci&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yei,sd&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=illoqqortoormiut,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=karkaralinsk,kz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=samarai,pg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tasiilaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kodiak,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port-cartier,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ponta do sol,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mar del plata,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=aykhal,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=arshan,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cotonou,bj&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hithadhoo,mv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=saint-philippe,re&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=gubkinskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=padang,id&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kaabong,ug&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=college,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=chegdomyn,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saint george,bm&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sentyabrskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=soyo,ao&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=norman wells,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=avarua,ck&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=khuzhir,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jalu,ly&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mys shmidta,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=east london,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tawkar,sd&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=manta,ec&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nikolskoye,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ponta do sol,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=glendive,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=black river,jm&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vestmannaeyjar,is&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=pevek,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=pisco,pe&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tasiilaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=axim,gh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vaini,to&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=barrow,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=santa cruz,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=quatre cocos,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lebu,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=puerto ayora,ec&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=belushya guba,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=chuy,uy&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nguiu,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=high level,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=canyon,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=solnechnyy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tilichiki,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=illoqqortoormiut,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=tiksi,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=khatanga,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mogadishu,so&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=torbay,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=adrar,dz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=brainerd,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ukiah,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=chokurdakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=seoul,kr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=coroico,bo&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=souillac,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=avarua,ck&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hilo,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=aviles,es&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=haukipudas,fi&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ilulissat,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kieta,pg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hithadhoo,mv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=chicama,pe&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hithadhoo,mv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=linqing,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saskylakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=shenjiamen,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cap-aux-meules,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bengkulu,id&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=saint-leu,re&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=aksarka,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yulara,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=karaul,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=fairbanks,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atar,mr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=east london,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=masuguru,tz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=muisne,ec&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tiksi,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=formoso do araguaia,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=torbay,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=novyye burasy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=chopovychi,ua&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rong kwang,th&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=butaritari,ki&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=viedma,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=umm lajj,sa&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cheltenham,gb&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=belushya guba,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=arraial do cabo,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rawannawi,ki&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=pirgos,gr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nicoya,cr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=okhotsk,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mumford,gh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=pimentel,pe&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cockburn harbour,tc&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=matay,eg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ustyuzhna,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=amla,in&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=biloela,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=butaritari,ki&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mar del plata,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=namatanai,pg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nikolskoye,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=puerto ayora,ec&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ereymentau,kz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nome,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saleaula,ws&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=tazovskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mindelo,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=buriti,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kahului,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saskylakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=half moon bay,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=chuy,uy&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=faanui,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sobolevo,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=fortuna,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=iqaluit,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=fukagawa,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=acara,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=kodiak,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=attawapiskat,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=soligalich,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tromso,no&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=namatanai,pg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vardo,no&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=hilo,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=alice,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tilichiki,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yellowknife,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=riyadh,sa&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=castro,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sayyan,ye&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=riaba,gq&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=tobol,kz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hirara,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=junction city,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=do gonbadan,ir&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mar del plata,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tasiilaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hermanus,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=castro,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sechura,pe&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=barrow,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=grand river south east,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=avarua,ck&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lompoc,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=doembang nangbuat,th&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=upernavik,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mahebourg,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=palabuhanratu,id&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=yellowknife,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kaitangata,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=nelson bay,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hermanus,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cabo san lucas,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=teneguiban,ph&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=codrington,ag&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=terra roxa,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ribeira grande,pt&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kavaratti,in&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yulara,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mahebourg,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vysokogornyy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=qaanaaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=amot,no&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=touros,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=san patricio,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hermanus,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=dunedin,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sjenica,rs&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=paamiut,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=wahran,dz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bur gabo,so&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=tasiilaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=danane,ci&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=alyangula,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=heihe,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mar del plata,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=iqaluit,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sao filipe,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=san cristobal,ec&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=begun,in&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=arraial do cabo,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albion,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tsihombe,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=new norfolk,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=codrington,ag&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=bealanana,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=alofi,nu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lebu,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=georgetown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=esperance,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=constitucion,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=zaragoza,es&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tiznit,ma&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=raahe,fi&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tumannyy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=te anau,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=hermanus,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=gisborne,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=meulaboh,id&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=carnarvon,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saint-philippe,re&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=loreto,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=east london,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mangai,cd&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=touros,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port elizabeth,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=huanren,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rocky mount,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=middle island,kn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=tuatapere,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=soldotna,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=avarua,ck&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=taolanaro,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=upernavik,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=upernavik,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=butaritari,ki&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hermanus,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=talnakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yar-sale,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=monrovia,lr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=norman wells,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=thompson,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hasaki,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bambous virieux,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=turki,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=alugan,ph&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mrirt,ma&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=ponta do sol,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=new norfolk,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=katsuura,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=clyde river,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=leona vicario,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=san quintin,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=pochutla,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=carmarthen,gb&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=tadine,nc&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=severo-kurilsk,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=brownsville,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=pangnirtung,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sitka,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=la reforma,mx&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nanortalik,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=barentsburg,sj&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=castro,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=porto novo,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=khonuu,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=fortuna,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mundgod,in&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cidreira,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=varhaug,no&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=srednekolymsk,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=atuona,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=smithers,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=new norfolk,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bredasdorp,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ribeira grande,pt&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=grand river south east,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=gat,ly&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=vardo,no&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=raga,sd&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=marsh harbour,bs&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=yaan,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=chapais,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mar del plata,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=attawapiskat,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=louisbourg,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=ponta do sol,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=arraial do cabo,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nikolskoye,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=soyo,ao&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nichinan,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=belushya guba,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=iqaluit,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ushuaia,ar&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=morondava,mg&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kletskaya,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saint-philippe,re&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ossora,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=castro,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=masuguru,tz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mataura,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=ostrovnoy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hilo,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hami,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=castro,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=new norfolk,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bur gabo,so&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=stepnyak,kz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=flinders,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=camacha,pt&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sitka,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mehamn,no&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saldanha,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=illoqqortoormiut,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=fort nelson,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port elizabeth,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bambous virieux,mu&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=zhangjiakou,cn&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saint-pierre,pm&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saint-joseph,re&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=knysna,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=esperance,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=cidreira,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jumla,np&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=warwick,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=lata,sb&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=cape town,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=jamestown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=victoria,sc&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=west allis,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sentyabrskiy,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=prince rupert,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=victoria,sc&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=ponta do sol,cv&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=tuktoyaktuk,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=kapaa,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=grand-lahou,ci&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=castro,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=namibe,ao&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=louisbourg,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=vredendal,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=vao,nc&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=hobart,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=albany,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=aklavik,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=katsuura,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=bluff,nz&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=georgetown,sh&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=rikitea,pf&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=port alfred,za&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=arraial do cabo,br&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=busselton,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=nantucket,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=katsuura,jp&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=mount isa,au&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=chokurdakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=samusu,ws&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    Missing weather information...skip
    http://api.openweathermap.org/data/2.5/forecast?q=lixourion,gr&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=saskylakh,ru&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=sitka,us&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=narsaq,gl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=thompson,ca&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    http://api.openweathermap.org/data/2.5/forecast?q=punta arenas,cl&units=IMPERIAL&mode=json&APPID=d705dc22dfd67b749ca0157dae5218e9
    


```python
#changing all data recieved from openweathermap api to numerical data
df_countries['Latitude'] = pd.to_numeric(df_countries['Latitude'])
df_countries['Longitude'] = pd.to_numeric(df_countries['Longitude'])
df_countries['Temperature (F)'] = pd.to_numeric(df_countries['Temperature (F)'])
df_countries['Humidity (%)'] = pd.to_numeric(df_countries['Humidity (%)'])
df_countries['Cloudiness (%)'] = pd.to_numeric(df_countries['Cloudiness (%)'])
df_countries['Wind Speed (mph)'] = pd.to_numeric(df_countries['Wind Speed (mph)'])
 
df_countries
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cities</th>
      <th>Country</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>Temperature (F)</th>
      <th>Humidity (%)</th>
      <th>Cloudiness (%)</th>
      <th>Wind Speed (mph)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>coatesville</td>
      <td>us</td>
      <td>39.9832</td>
      <td>-75.8239</td>
      <td>32.95</td>
      <td>52.0</td>
      <td>12.0</td>
      <td>7.87</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ozernovskiy</td>
      <td>ru</td>
      <td>51.5000</td>
      <td>156.5167</td>
      <td>25.20</td>
      <td>93.0</td>
      <td>80.0</td>
      <td>12.91</td>
    </tr>
    <tr>
      <th>2</th>
      <td>klaksvik</td>
      <td>fo</td>
      <td>62.2266</td>
      <td>-6.5891</td>
      <td>38.43</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>24.65</td>
    </tr>
    <tr>
      <th>3</th>
      <td>troitskiy</td>
      <td>ru</td>
      <td>45.1462</td>
      <td>38.1411</td>
      <td>41.77</td>
      <td>78.0</td>
      <td>56.0</td>
      <td>10.67</td>
    </tr>
    <tr>
      <th>4</th>
      <td>sao jose da coroa grande</td>
      <td>br</td>
      <td>-8.8978</td>
      <td>-35.1478</td>
      <td>78.84</td>
      <td>90.0</td>
      <td>12.0</td>
      <td>10.22</td>
    </tr>
    <tr>
      <th>5</th>
      <td>mahebourg</td>
      <td>mu</td>
      <td>-20.4081</td>
      <td>57.7000</td>
      <td>80.49</td>
      <td>82.0</td>
      <td>88.0</td>
      <td>17.60</td>
    </tr>
    <tr>
      <th>6</th>
      <td>catalao</td>
      <td>br</td>
      <td>-18.1659</td>
      <td>-47.9464</td>
      <td>76.23</td>
      <td>75.0</td>
      <td>8.0</td>
      <td>2.95</td>
    </tr>
    <tr>
      <th>7</th>
      <td>taolanaro</td>
      <td>mg</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>ushuaia</td>
      <td>ar</td>
      <td>-54.8070</td>
      <td>-68.3074</td>
      <td>44.71</td>
      <td>88.0</td>
      <td>0.0</td>
      <td>10.67</td>
    </tr>
    <tr>
      <th>9</th>
      <td>kapaa</td>
      <td>us</td>
      <td>22.0752</td>
      <td>-159.3190</td>
      <td>74.97</td>
      <td>80.0</td>
      <td>88.0</td>
      <td>12.80</td>
    </tr>
    <tr>
      <th>10</th>
      <td>jaruco</td>
      <td>cu</td>
      <td>23.0439</td>
      <td>-82.0102</td>
      <td>64.27</td>
      <td>65.0</td>
      <td>0.0</td>
      <td>11.34</td>
    </tr>
    <tr>
      <th>11</th>
      <td>puerto ayora</td>
      <td>ec</td>
      <td>-0.7394</td>
      <td>-90.3518</td>
      <td>82.00</td>
      <td>99.0</td>
      <td>56.0</td>
      <td>6.20</td>
    </tr>
    <tr>
      <th>12</th>
      <td>rikitea</td>
      <td>pf</td>
      <td>-23.1203</td>
      <td>-134.9692</td>
      <td>80.19</td>
      <td>100.0</td>
      <td>20.0</td>
      <td>7.76</td>
    </tr>
    <tr>
      <th>13</th>
      <td>quang ngai</td>
      <td>vn</td>
      <td>15.1167</td>
      <td>108.8000</td>
      <td>68.22</td>
      <td>90.0</td>
      <td>24.0</td>
      <td>2.95</td>
    </tr>
    <tr>
      <th>14</th>
      <td>port elizabeth</td>
      <td>za</td>
      <td>-33.9180</td>
      <td>25.5701</td>
      <td>68.85</td>
      <td>95.0</td>
      <td>76.0</td>
      <td>19.17</td>
    </tr>
    <tr>
      <th>15</th>
      <td>ponta do sol</td>
      <td>cv</td>
      <td>17.1994</td>
      <td>-25.0920</td>
      <td>71.28</td>
      <td>99.0</td>
      <td>0.0</td>
      <td>15.82</td>
    </tr>
    <tr>
      <th>16</th>
      <td>lebu</td>
      <td>cl</td>
      <td>-37.6167</td>
      <td>-73.6501</td>
      <td>60.84</td>
      <td>100.0</td>
      <td>36.0</td>
      <td>7.87</td>
    </tr>
    <tr>
      <th>17</th>
      <td>puerto ayora</td>
      <td>ec</td>
      <td>-0.7394</td>
      <td>-90.3518</td>
      <td>82.00</td>
      <td>99.0</td>
      <td>56.0</td>
      <td>6.20</td>
    </tr>
    <tr>
      <th>18</th>
      <td>lavrentiya</td>
      <td>ru</td>
      <td>65.5842</td>
      <td>-170.9890</td>
      <td>0.27</td>
      <td>100.0</td>
      <td>80.0</td>
      <td>17.83</td>
    </tr>
    <tr>
      <th>19</th>
      <td>saskylakh</td>
      <td>ru</td>
      <td>71.9650</td>
      <td>114.0939</td>
      <td>-34.39</td>
      <td>63.0</td>
      <td>32.0</td>
      <td>3.06</td>
    </tr>
    <tr>
      <th>20</th>
      <td>ushuaia</td>
      <td>ar</td>
      <td>-54.8070</td>
      <td>-68.3074</td>
      <td>44.71</td>
      <td>88.0</td>
      <td>0.0</td>
      <td>10.67</td>
    </tr>
    <tr>
      <th>21</th>
      <td>barrow</td>
      <td>us</td>
      <td>39.5062</td>
      <td>-90.4016</td>
      <td>38.97</td>
      <td>49.0</td>
      <td>0.0</td>
      <td>18.05</td>
    </tr>
    <tr>
      <th>22</th>
      <td>ceres</td>
      <td>za</td>
      <td>-33.3684</td>
      <td>19.3092</td>
      <td>57.87</td>
      <td>95.0</td>
      <td>68.0</td>
      <td>2.17</td>
    </tr>
    <tr>
      <th>23</th>
      <td>punta arenas</td>
      <td>cl</td>
      <td>-53.1627</td>
      <td>-70.9081</td>
      <td>44.92</td>
      <td>94.0</td>
      <td>8.0</td>
      <td>21.18</td>
    </tr>
    <tr>
      <th>24</th>
      <td>jamestown</td>
      <td>sh</td>
      <td>-15.9388</td>
      <td>-5.7168</td>
      <td>74.70</td>
      <td>100.0</td>
      <td>48.0</td>
      <td>14.70</td>
    </tr>
    <tr>
      <th>25</th>
      <td>ushuaia</td>
      <td>ar</td>
      <td>-54.8070</td>
      <td>-68.3074</td>
      <td>44.71</td>
      <td>88.0</td>
      <td>0.0</td>
      <td>10.67</td>
    </tr>
    <tr>
      <th>26</th>
      <td>tuktoyaktuk</td>
      <td>ca</td>
      <td>69.4440</td>
      <td>-133.0320</td>
      <td>15.64</td>
      <td>87.0</td>
      <td>24.0</td>
      <td>0.60</td>
    </tr>
    <tr>
      <th>27</th>
      <td>busselton</td>
      <td>au</td>
      <td>-33.6445</td>
      <td>115.3489</td>
      <td>70.11</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>12.01</td>
    </tr>
    <tr>
      <th>28</th>
      <td>makakilo city</td>
      <td>us</td>
      <td>21.3469</td>
      <td>-158.0859</td>
      <td>76.69</td>
      <td>63.0</td>
      <td>88.0</td>
      <td>14.47</td>
    </tr>
    <tr>
      <th>29</th>
      <td>vaini</td>
      <td>to</td>
      <td>-21.2001</td>
      <td>-175.2000</td>
      <td>84.60</td>
      <td>99.0</td>
      <td>88.0</td>
      <td>13.24</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>770</th>
      <td>tuktoyaktuk</td>
      <td>ca</td>
      <td>69.4440</td>
      <td>-133.0320</td>
      <td>15.64</td>
      <td>87.0</td>
      <td>24.0</td>
      <td>0.60</td>
    </tr>
    <tr>
      <th>771</th>
      <td>kapaa</td>
      <td>us</td>
      <td>22.0752</td>
      <td>-159.3190</td>
      <td>74.97</td>
      <td>80.0</td>
      <td>88.0</td>
      <td>12.80</td>
    </tr>
    <tr>
      <th>772</th>
      <td>grand-lahou</td>
      <td>ci</td>
      <td>5.2443</td>
      <td>-5.0035</td>
      <td>76.05</td>
      <td>95.0</td>
      <td>20.0</td>
      <td>4.07</td>
    </tr>
    <tr>
      <th>773</th>
      <td>castro</td>
      <td>cl</td>
      <td>-42.4824</td>
      <td>-73.7644</td>
      <td>54.09</td>
      <td>99.0</td>
      <td>92.0</td>
      <td>11.01</td>
    </tr>
    <tr>
      <th>774</th>
      <td>rikitea</td>
      <td>pf</td>
      <td>-23.1203</td>
      <td>-134.9692</td>
      <td>80.19</td>
      <td>100.0</td>
      <td>20.0</td>
      <td>7.76</td>
    </tr>
    <tr>
      <th>775</th>
      <td>namibe</td>
      <td>ao</td>
      <td>-15.1902</td>
      <td>12.1531</td>
      <td>75.60</td>
      <td>100.0</td>
      <td>32.0</td>
      <td>2.51</td>
    </tr>
    <tr>
      <th>776</th>
      <td>louisbourg</td>
      <td>ca</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>777</th>
      <td>vredendal</td>
      <td>za</td>
      <td>-31.6795</td>
      <td>18.4922</td>
      <td>61.29</td>
      <td>96.0</td>
      <td>92.0</td>
      <td>3.18</td>
    </tr>
    <tr>
      <th>778</th>
      <td>vao</td>
      <td>nc</td>
      <td>-22.6667</td>
      <td>167.4833</td>
      <td>80.28</td>
      <td>95.0</td>
      <td>88.0</td>
      <td>20.74</td>
    </tr>
    <tr>
      <th>779</th>
      <td>hobart</td>
      <td>au</td>
      <td>-42.8826</td>
      <td>147.3281</td>
      <td>67.12</td>
      <td>65.0</td>
      <td>76.0</td>
      <td>3.18</td>
    </tr>
    <tr>
      <th>780</th>
      <td>albany</td>
      <td>au</td>
      <td>-35.0248</td>
      <td>117.8836</td>
      <td>68.49</td>
      <td>85.0</td>
      <td>92.0</td>
      <td>6.31</td>
    </tr>
    <tr>
      <th>781</th>
      <td>aklavik</td>
      <td>ca</td>
      <td>68.2183</td>
      <td>-135.0136</td>
      <td>20.53</td>
      <td>81.0</td>
      <td>0.0</td>
      <td>3.18</td>
    </tr>
    <tr>
      <th>782</th>
      <td>katsuura</td>
      <td>jp</td>
      <td>33.9258</td>
      <td>134.5050</td>
      <td>58.46</td>
      <td>76.0</td>
      <td>0.0</td>
      <td>2.28</td>
    </tr>
    <tr>
      <th>783</th>
      <td>bluff</td>
      <td>nz</td>
      <td>-46.6000</td>
      <td>168.3333</td>
      <td>59.94</td>
      <td>96.0</td>
      <td>44.0</td>
      <td>29.24</td>
    </tr>
    <tr>
      <th>784</th>
      <td>georgetown</td>
      <td>sh</td>
      <td>-7.9334</td>
      <td>-14.4167</td>
      <td>78.84</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>11.68</td>
    </tr>
    <tr>
      <th>785</th>
      <td>rikitea</td>
      <td>pf</td>
      <td>-23.1203</td>
      <td>-134.9692</td>
      <td>80.19</td>
      <td>100.0</td>
      <td>20.0</td>
      <td>7.76</td>
    </tr>
    <tr>
      <th>786</th>
      <td>port alfred</td>
      <td>za</td>
      <td>-33.5906</td>
      <td>26.8910</td>
      <td>70.29</td>
      <td>92.0</td>
      <td>36.0</td>
      <td>11.01</td>
    </tr>
    <tr>
      <th>787</th>
      <td>arraial do cabo</td>
      <td>br</td>
      <td>-22.9663</td>
      <td>-42.0245</td>
      <td>77.72</td>
      <td>94.0</td>
      <td>88.0</td>
      <td>8.43</td>
    </tr>
    <tr>
      <th>788</th>
      <td>busselton</td>
      <td>au</td>
      <td>-33.6445</td>
      <td>115.3489</td>
      <td>70.11</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>12.01</td>
    </tr>
    <tr>
      <th>789</th>
      <td>nantucket</td>
      <td>us</td>
      <td>41.2835</td>
      <td>-70.0995</td>
      <td>33.40</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>33.93</td>
    </tr>
    <tr>
      <th>790</th>
      <td>katsuura</td>
      <td>jp</td>
      <td>33.9258</td>
      <td>134.5050</td>
      <td>58.46</td>
      <td>76.0</td>
      <td>0.0</td>
      <td>2.28</td>
    </tr>
    <tr>
      <th>791</th>
      <td>mount isa</td>
      <td>au</td>
      <td>-20.7290</td>
      <td>139.4932</td>
      <td>87.89</td>
      <td>35.0</td>
      <td>0.0</td>
      <td>7.99</td>
    </tr>
    <tr>
      <th>792</th>
      <td>chokurdakh</td>
      <td>ru</td>
      <td>70.6192</td>
      <td>147.9022</td>
      <td>-24.67</td>
      <td>75.0</td>
      <td>32.0</td>
      <td>9.33</td>
    </tr>
    <tr>
      <th>793</th>
      <td>samusu</td>
      <td>ws</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>794</th>
      <td>lixourion</td>
      <td>gr</td>
      <td>38.2019</td>
      <td>20.4314</td>
      <td>58.68</td>
      <td>99.0</td>
      <td>0.0</td>
      <td>14.70</td>
    </tr>
    <tr>
      <th>795</th>
      <td>saskylakh</td>
      <td>ru</td>
      <td>71.9650</td>
      <td>114.0939</td>
      <td>-34.39</td>
      <td>63.0</td>
      <td>32.0</td>
      <td>3.06</td>
    </tr>
    <tr>
      <th>796</th>
      <td>sitka</td>
      <td>us</td>
      <td>37.1750</td>
      <td>-99.6516</td>
      <td>53.64</td>
      <td>30.0</td>
      <td>0.0</td>
      <td>4.97</td>
    </tr>
    <tr>
      <th>797</th>
      <td>narsaq</td>
      <td>gl</td>
      <td>60.9127</td>
      <td>-46.0453</td>
      <td>12.83</td>
      <td>49.0</td>
      <td>0.0</td>
      <td>1.61</td>
    </tr>
    <tr>
      <th>798</th>
      <td>thompson</td>
      <td>ca</td>
      <td>55.7433</td>
      <td>-97.8635</td>
      <td>42.10</td>
      <td>66.0</td>
      <td>0.0</td>
      <td>10.00</td>
    </tr>
    <tr>
      <th>799</th>
      <td>punta arenas</td>
      <td>cl</td>
      <td>-53.1627</td>
      <td>-70.9081</td>
      <td>44.92</td>
      <td>94.0</td>
      <td>8.0</td>
      <td>21.18</td>
    </tr>
  </tbody>
</table>
<p>800 rows × 8 columns</p>
</div>




```python
length_of_original_DF = len(df_countries)
length_after_dropna = len(df_countries.dropna())

missing_weather_info = length_of_original_DF - length_after_dropna
```


```python
print(' {} cities did not contain weather\
 information. These cities, will be dropped from this dataframe.'.format(missing_weather_info))

print('\n')

print("The dataframe used for plotting contains weather information for {} different cities. "\
      .format(len(df_countries.dropna())))
```

     108 cities did not contain weather information. These cities, will be dropped from this dataframe.
    
    
    The dataframe used for plotting contains weather information for 692 different cities. 
    


```python
#Resaving the new citipy data into a CSV file and reading it at the same time
df_countries = df_countries.dropna()
df_countries.to_csv(path_or_buf='df_countries.csv', encoding="utf-8", index=False)
df_countries = pd.read_csv("df_countries.csv")
df_countries
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Cities</th>
      <th>Country</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>Temperature (F)</th>
      <th>Humidity (%)</th>
      <th>Cloudiness (%)</th>
      <th>Wind Speed (mph)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>coatesville</td>
      <td>us</td>
      <td>39.9832</td>
      <td>-75.8239</td>
      <td>32.95</td>
      <td>52.0</td>
      <td>12.0</td>
      <td>7.87</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ozernovskiy</td>
      <td>ru</td>
      <td>51.5000</td>
      <td>156.5167</td>
      <td>25.20</td>
      <td>93.0</td>
      <td>80.0</td>
      <td>12.91</td>
    </tr>
    <tr>
      <th>2</th>
      <td>klaksvik</td>
      <td>fo</td>
      <td>62.2266</td>
      <td>-6.5891</td>
      <td>38.43</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>24.65</td>
    </tr>
    <tr>
      <th>3</th>
      <td>troitskiy</td>
      <td>ru</td>
      <td>45.1462</td>
      <td>38.1411</td>
      <td>41.77</td>
      <td>78.0</td>
      <td>56.0</td>
      <td>10.67</td>
    </tr>
    <tr>
      <th>4</th>
      <td>sao jose da coroa grande</td>
      <td>br</td>
      <td>-8.8978</td>
      <td>-35.1478</td>
      <td>78.84</td>
      <td>90.0</td>
      <td>12.0</td>
      <td>10.22</td>
    </tr>
    <tr>
      <th>5</th>
      <td>mahebourg</td>
      <td>mu</td>
      <td>-20.4081</td>
      <td>57.7000</td>
      <td>80.49</td>
      <td>82.0</td>
      <td>88.0</td>
      <td>17.60</td>
    </tr>
    <tr>
      <th>6</th>
      <td>catalao</td>
      <td>br</td>
      <td>-18.1659</td>
      <td>-47.9464</td>
      <td>76.23</td>
      <td>75.0</td>
      <td>8.0</td>
      <td>2.95</td>
    </tr>
    <tr>
      <th>7</th>
      <td>ushuaia</td>
      <td>ar</td>
      <td>-54.8070</td>
      <td>-68.3074</td>
      <td>44.71</td>
      <td>88.0</td>
      <td>0.0</td>
      <td>10.67</td>
    </tr>
    <tr>
      <th>8</th>
      <td>kapaa</td>
      <td>us</td>
      <td>22.0752</td>
      <td>-159.3190</td>
      <td>74.97</td>
      <td>80.0</td>
      <td>88.0</td>
      <td>12.80</td>
    </tr>
    <tr>
      <th>9</th>
      <td>jaruco</td>
      <td>cu</td>
      <td>23.0439</td>
      <td>-82.0102</td>
      <td>64.27</td>
      <td>65.0</td>
      <td>0.0</td>
      <td>11.34</td>
    </tr>
    <tr>
      <th>10</th>
      <td>puerto ayora</td>
      <td>ec</td>
      <td>-0.7394</td>
      <td>-90.3518</td>
      <td>82.00</td>
      <td>99.0</td>
      <td>56.0</td>
      <td>6.20</td>
    </tr>
    <tr>
      <th>11</th>
      <td>rikitea</td>
      <td>pf</td>
      <td>-23.1203</td>
      <td>-134.9692</td>
      <td>80.19</td>
      <td>100.0</td>
      <td>20.0</td>
      <td>7.76</td>
    </tr>
    <tr>
      <th>12</th>
      <td>quang ngai</td>
      <td>vn</td>
      <td>15.1167</td>
      <td>108.8000</td>
      <td>68.22</td>
      <td>90.0</td>
      <td>24.0</td>
      <td>2.95</td>
    </tr>
    <tr>
      <th>13</th>
      <td>port elizabeth</td>
      <td>za</td>
      <td>-33.9180</td>
      <td>25.5701</td>
      <td>68.85</td>
      <td>95.0</td>
      <td>76.0</td>
      <td>19.17</td>
    </tr>
    <tr>
      <th>14</th>
      <td>ponta do sol</td>
      <td>cv</td>
      <td>17.1994</td>
      <td>-25.0920</td>
      <td>71.28</td>
      <td>99.0</td>
      <td>0.0</td>
      <td>15.82</td>
    </tr>
    <tr>
      <th>15</th>
      <td>lebu</td>
      <td>cl</td>
      <td>-37.6167</td>
      <td>-73.6501</td>
      <td>60.84</td>
      <td>100.0</td>
      <td>36.0</td>
      <td>7.87</td>
    </tr>
    <tr>
      <th>16</th>
      <td>puerto ayora</td>
      <td>ec</td>
      <td>-0.7394</td>
      <td>-90.3518</td>
      <td>82.00</td>
      <td>99.0</td>
      <td>56.0</td>
      <td>6.20</td>
    </tr>
    <tr>
      <th>17</th>
      <td>lavrentiya</td>
      <td>ru</td>
      <td>65.5842</td>
      <td>-170.9890</td>
      <td>0.27</td>
      <td>100.0</td>
      <td>80.0</td>
      <td>17.83</td>
    </tr>
    <tr>
      <th>18</th>
      <td>saskylakh</td>
      <td>ru</td>
      <td>71.9650</td>
      <td>114.0939</td>
      <td>-34.39</td>
      <td>63.0</td>
      <td>32.0</td>
      <td>3.06</td>
    </tr>
    <tr>
      <th>19</th>
      <td>ushuaia</td>
      <td>ar</td>
      <td>-54.8070</td>
      <td>-68.3074</td>
      <td>44.71</td>
      <td>88.0</td>
      <td>0.0</td>
      <td>10.67</td>
    </tr>
    <tr>
      <th>20</th>
      <td>barrow</td>
      <td>us</td>
      <td>39.5062</td>
      <td>-90.4016</td>
      <td>38.97</td>
      <td>49.0</td>
      <td>0.0</td>
      <td>18.05</td>
    </tr>
    <tr>
      <th>21</th>
      <td>ceres</td>
      <td>za</td>
      <td>-33.3684</td>
      <td>19.3092</td>
      <td>57.87</td>
      <td>95.0</td>
      <td>68.0</td>
      <td>2.17</td>
    </tr>
    <tr>
      <th>22</th>
      <td>punta arenas</td>
      <td>cl</td>
      <td>-53.1627</td>
      <td>-70.9081</td>
      <td>44.92</td>
      <td>94.0</td>
      <td>8.0</td>
      <td>21.18</td>
    </tr>
    <tr>
      <th>23</th>
      <td>jamestown</td>
      <td>sh</td>
      <td>-15.9388</td>
      <td>-5.7168</td>
      <td>74.70</td>
      <td>100.0</td>
      <td>48.0</td>
      <td>14.70</td>
    </tr>
    <tr>
      <th>24</th>
      <td>ushuaia</td>
      <td>ar</td>
      <td>-54.8070</td>
      <td>-68.3074</td>
      <td>44.71</td>
      <td>88.0</td>
      <td>0.0</td>
      <td>10.67</td>
    </tr>
    <tr>
      <th>25</th>
      <td>tuktoyaktuk</td>
      <td>ca</td>
      <td>69.4440</td>
      <td>-133.0320</td>
      <td>15.64</td>
      <td>87.0</td>
      <td>24.0</td>
      <td>0.60</td>
    </tr>
    <tr>
      <th>26</th>
      <td>busselton</td>
      <td>au</td>
      <td>-33.6445</td>
      <td>115.3489</td>
      <td>70.11</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>12.01</td>
    </tr>
    <tr>
      <th>27</th>
      <td>makakilo city</td>
      <td>us</td>
      <td>21.3469</td>
      <td>-158.0859</td>
      <td>76.69</td>
      <td>63.0</td>
      <td>88.0</td>
      <td>14.47</td>
    </tr>
    <tr>
      <th>28</th>
      <td>vaini</td>
      <td>to</td>
      <td>-21.2001</td>
      <td>-175.2000</td>
      <td>84.60</td>
      <td>99.0</td>
      <td>88.0</td>
      <td>13.24</td>
    </tr>
    <tr>
      <th>29</th>
      <td>tasiilaq</td>
      <td>gl</td>
      <td>65.6145</td>
      <td>-37.6368</td>
      <td>12.07</td>
      <td>92.0</td>
      <td>0.0</td>
      <td>6.42</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>662</th>
      <td>port alfred</td>
      <td>za</td>
      <td>-33.5906</td>
      <td>26.8910</td>
      <td>70.29</td>
      <td>92.0</td>
      <td>36.0</td>
      <td>11.01</td>
    </tr>
    <tr>
      <th>663</th>
      <td>ponta do sol</td>
      <td>cv</td>
      <td>17.1994</td>
      <td>-25.0920</td>
      <td>71.28</td>
      <td>99.0</td>
      <td>0.0</td>
      <td>15.82</td>
    </tr>
    <tr>
      <th>664</th>
      <td>tuktoyaktuk</td>
      <td>ca</td>
      <td>69.4440</td>
      <td>-133.0320</td>
      <td>15.64</td>
      <td>87.0</td>
      <td>24.0</td>
      <td>0.60</td>
    </tr>
    <tr>
      <th>665</th>
      <td>kapaa</td>
      <td>us</td>
      <td>22.0752</td>
      <td>-159.3190</td>
      <td>74.97</td>
      <td>80.0</td>
      <td>88.0</td>
      <td>12.80</td>
    </tr>
    <tr>
      <th>666</th>
      <td>grand-lahou</td>
      <td>ci</td>
      <td>5.2443</td>
      <td>-5.0035</td>
      <td>76.05</td>
      <td>95.0</td>
      <td>20.0</td>
      <td>4.07</td>
    </tr>
    <tr>
      <th>667</th>
      <td>castro</td>
      <td>cl</td>
      <td>-42.4824</td>
      <td>-73.7644</td>
      <td>54.09</td>
      <td>99.0</td>
      <td>92.0</td>
      <td>11.01</td>
    </tr>
    <tr>
      <th>668</th>
      <td>rikitea</td>
      <td>pf</td>
      <td>-23.1203</td>
      <td>-134.9692</td>
      <td>80.19</td>
      <td>100.0</td>
      <td>20.0</td>
      <td>7.76</td>
    </tr>
    <tr>
      <th>669</th>
      <td>namibe</td>
      <td>ao</td>
      <td>-15.1902</td>
      <td>12.1531</td>
      <td>75.60</td>
      <td>100.0</td>
      <td>32.0</td>
      <td>2.51</td>
    </tr>
    <tr>
      <th>670</th>
      <td>vredendal</td>
      <td>za</td>
      <td>-31.6795</td>
      <td>18.4922</td>
      <td>61.29</td>
      <td>96.0</td>
      <td>92.0</td>
      <td>3.18</td>
    </tr>
    <tr>
      <th>671</th>
      <td>vao</td>
      <td>nc</td>
      <td>-22.6667</td>
      <td>167.4833</td>
      <td>80.28</td>
      <td>95.0</td>
      <td>88.0</td>
      <td>20.74</td>
    </tr>
    <tr>
      <th>672</th>
      <td>hobart</td>
      <td>au</td>
      <td>-42.8826</td>
      <td>147.3281</td>
      <td>67.12</td>
      <td>65.0</td>
      <td>76.0</td>
      <td>3.18</td>
    </tr>
    <tr>
      <th>673</th>
      <td>albany</td>
      <td>au</td>
      <td>-35.0248</td>
      <td>117.8836</td>
      <td>68.49</td>
      <td>85.0</td>
      <td>92.0</td>
      <td>6.31</td>
    </tr>
    <tr>
      <th>674</th>
      <td>aklavik</td>
      <td>ca</td>
      <td>68.2183</td>
      <td>-135.0136</td>
      <td>20.53</td>
      <td>81.0</td>
      <td>0.0</td>
      <td>3.18</td>
    </tr>
    <tr>
      <th>675</th>
      <td>katsuura</td>
      <td>jp</td>
      <td>33.9258</td>
      <td>134.5050</td>
      <td>58.46</td>
      <td>76.0</td>
      <td>0.0</td>
      <td>2.28</td>
    </tr>
    <tr>
      <th>676</th>
      <td>bluff</td>
      <td>nz</td>
      <td>-46.6000</td>
      <td>168.3333</td>
      <td>59.94</td>
      <td>96.0</td>
      <td>44.0</td>
      <td>29.24</td>
    </tr>
    <tr>
      <th>677</th>
      <td>georgetown</td>
      <td>sh</td>
      <td>-7.9334</td>
      <td>-14.4167</td>
      <td>78.84</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>11.68</td>
    </tr>
    <tr>
      <th>678</th>
      <td>rikitea</td>
      <td>pf</td>
      <td>-23.1203</td>
      <td>-134.9692</td>
      <td>80.19</td>
      <td>100.0</td>
      <td>20.0</td>
      <td>7.76</td>
    </tr>
    <tr>
      <th>679</th>
      <td>port alfred</td>
      <td>za</td>
      <td>-33.5906</td>
      <td>26.8910</td>
      <td>70.29</td>
      <td>92.0</td>
      <td>36.0</td>
      <td>11.01</td>
    </tr>
    <tr>
      <th>680</th>
      <td>arraial do cabo</td>
      <td>br</td>
      <td>-22.9663</td>
      <td>-42.0245</td>
      <td>77.72</td>
      <td>94.0</td>
      <td>88.0</td>
      <td>8.43</td>
    </tr>
    <tr>
      <th>681</th>
      <td>busselton</td>
      <td>au</td>
      <td>-33.6445</td>
      <td>115.3489</td>
      <td>70.11</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>12.01</td>
    </tr>
    <tr>
      <th>682</th>
      <td>nantucket</td>
      <td>us</td>
      <td>41.2835</td>
      <td>-70.0995</td>
      <td>33.40</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>33.93</td>
    </tr>
    <tr>
      <th>683</th>
      <td>katsuura</td>
      <td>jp</td>
      <td>33.9258</td>
      <td>134.5050</td>
      <td>58.46</td>
      <td>76.0</td>
      <td>0.0</td>
      <td>2.28</td>
    </tr>
    <tr>
      <th>684</th>
      <td>mount isa</td>
      <td>au</td>
      <td>-20.7290</td>
      <td>139.4932</td>
      <td>87.89</td>
      <td>35.0</td>
      <td>0.0</td>
      <td>7.99</td>
    </tr>
    <tr>
      <th>685</th>
      <td>chokurdakh</td>
      <td>ru</td>
      <td>70.6192</td>
      <td>147.9022</td>
      <td>-24.67</td>
      <td>75.0</td>
      <td>32.0</td>
      <td>9.33</td>
    </tr>
    <tr>
      <th>686</th>
      <td>lixourion</td>
      <td>gr</td>
      <td>38.2019</td>
      <td>20.4314</td>
      <td>58.68</td>
      <td>99.0</td>
      <td>0.0</td>
      <td>14.70</td>
    </tr>
    <tr>
      <th>687</th>
      <td>saskylakh</td>
      <td>ru</td>
      <td>71.9650</td>
      <td>114.0939</td>
      <td>-34.39</td>
      <td>63.0</td>
      <td>32.0</td>
      <td>3.06</td>
    </tr>
    <tr>
      <th>688</th>
      <td>sitka</td>
      <td>us</td>
      <td>37.1750</td>
      <td>-99.6516</td>
      <td>53.64</td>
      <td>30.0</td>
      <td>0.0</td>
      <td>4.97</td>
    </tr>
    <tr>
      <th>689</th>
      <td>narsaq</td>
      <td>gl</td>
      <td>60.9127</td>
      <td>-46.0453</td>
      <td>12.83</td>
      <td>49.0</td>
      <td>0.0</td>
      <td>1.61</td>
    </tr>
    <tr>
      <th>690</th>
      <td>thompson</td>
      <td>ca</td>
      <td>55.7433</td>
      <td>-97.8635</td>
      <td>42.10</td>
      <td>66.0</td>
      <td>0.0</td>
      <td>10.00</td>
    </tr>
    <tr>
      <th>691</th>
      <td>punta arenas</td>
      <td>cl</td>
      <td>-53.1627</td>
      <td>-70.9081</td>
      <td>44.92</td>
      <td>94.0</td>
      <td>8.0</td>
      <td>21.18</td>
    </tr>
  </tbody>
</table>
<p>692 rows × 8 columns</p>
</div>




```python
# Scatter Plot for Temperature (F) vs. Latitude

date = time.strftime("%m/%d/%Y")
# print(date)
plt.scatter(df_countries['Latitude'],df_countries['Temperature (F)'])
plt.title(f"Temperature (F) df_countries vs. Latitude {date}")
plt.xlabel("Latitude")
plt.ylabel("Temperature (F)")
plt.style.use('ggplot')
plt.savefig("Temperature (F).png")
plt.show()
```


![png](output_11_0.png)



```python
# # Scatter Plot for Humidity (%) vs. Latitude

plt.scatter(df_countries['Latitude'], df_countries['Humidity (%)'])
plt.title(f"Humidity (%) vs. Latitude {date}")
plt.xlabel("Latitude")
plt.ylabel("Humidity (%)")
plt.style.use('ggplot')
plt.savefig("Humidity (%).png")
plt.show()
```


![png](output_12_0.png)



```python
#Scatter Plot for Cloudiness (%) vs. Latitude

plt.scatter(df_countries['Latitude'], df_countries['Cloudiness (%)'])
plt.title(f"Cloudiness (%) vs. Latitude {date}")
plt.xlabel("Latitude")
plt.ylabel("Cloudiness (%)")
plt.style.use('ggplot')
plt.savefig("Cloudiness (%).png")
plt.show()
```


![png](output_13_0.png)



```python
# # Scatter Plot for Wind Speed (mph) vs. Latitude

plt.scatter(df_countries['Latitude'], df_countries['Wind Speed (mph)'])
plt.title(f"'Wind Speed (mph)' vs. Latitude {date}")
plt.xlabel("Latitude")
plt.ylabel('Wind Speed (mph)')
plt.style.use('ggplot')
plt.savefig('Wind Speed (mph).png')
plt.show()
```


![png](output_14_0.png)



```python
#OBSERVATIONS
 # 1 - Temperature seems bo be high picking from 40°F to 80°F then dropping down towards the equator, 
 # whis shows that the tempratures increases as it is approaching the equator. 


 # 2 - Humidity around Equator seems to be in the range on 18 (%) - 100 (%), 
    # which means that Humity is very high above the equator 

 # 3 Wind speed for most of the cities seems to fall under 5 (mph) below the equator,which seems to be normal on land and on Sea
#also Looking at the Cloud, it was well spread all over the cities but have a little clog at 0 mergin below the equator.

```
